import "@hotwired/turbo-rails"
import "libraries/trix"
import "controllers";
